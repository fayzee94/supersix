<div class="">
 <table>
 <tr><th>Team</th><th>W</th><th>D</th><th>L</th><th>GS</th><th>GA</th></tr>
 <?php foreach($teams as $team) { ?>
 			<tr><td><?php echo $team['name']; ?></td></tr>
 	<?php } ?>
 </table>
</div>
